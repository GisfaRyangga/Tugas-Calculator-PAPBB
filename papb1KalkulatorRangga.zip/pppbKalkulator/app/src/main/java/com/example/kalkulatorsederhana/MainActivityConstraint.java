package com.example.kalkulatorsederhana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivityConstraint extends AppCompatActivity {
    EditText et1,et2;
    Button plus, min, times, div;
    TextView total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_constraint);

        et1 = findViewById(R.id.angka1);
        et2 = findViewById(R.id.angka2);
        total = findViewById(R.id.hasil);
        plus = findViewById(R.id.tambah);
        min = findViewById(R.id.kurang);
        times = findViewById(R.id.kali);
        div = findViewById(R.id.bagi);

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double bil1, bil2, jadi;
                bil1 = Double.valueOf(et1.getText().toString().trim());
                bil2 = Double.valueOf(et2.getText().toString().trim());
                jadi = bil1+bil2;
                String jadi1 = String.valueOf(jadi);
                total.setText(jadi1);
            }
        });

        min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double bil1, bil2, jadi;
                bil1 = Double.valueOf(et1.getText().toString().trim());
                bil2 = Double.valueOf(et2.getText().toString().trim());
                jadi = bil1-bil2;
                String jadi1 = String.valueOf(jadi);
                total.setText(jadi1);
            }
        });

        times.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double bil1, bil2, jadi;
                bil1 = Double.valueOf(et1.getText().toString().trim());
                bil2 = Double.valueOf(et2.getText().toString().trim());
                jadi = bil1*bil2;
                String jadi1 = String.valueOf(jadi);
                total.setText(jadi1);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double bil1, bil2, jadi;
                bil1 = Double.valueOf(et1.getText().toString().trim());
                bil2 = Double.valueOf(et2.getText().toString().trim());
                jadi = bil1/bil2;
                String jadi1 = String.valueOf(jadi);
                total.setText(jadi1);
            }
        });
    }
}